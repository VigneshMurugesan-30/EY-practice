#!/bin/bash

echo "🔧 Step 1: Splitting audio and video..."
cd splitter
docker build -t splitter .
docker run --rm \
  -v "$(pwd)/../input:/app/input" \
  -v "$(pwd)/output:/app/output" \
  splitter

echo "🎤 Step 2: Running Demucs separation..."
cd ../demucs
docker build -t demucs .
docker run --rm \
  -v "$(pwd)/../splitter/output:/app/input" \
  -v "$(pwd)/output:/app/output" \
  demucs

echo "✅ Pipeline complete!"
