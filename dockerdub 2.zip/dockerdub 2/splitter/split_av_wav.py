import subprocess
subprocess.run([
    "ffmpeg", "-i", "input/input_video.mp4",
    "-vn", "-acodec", "pcm_s16le", "-ar", "44100", "-ac", "2",
    "output/output_audio.wav"
], check=True)
subprocess.run([
    "ffmpeg", "-i", "input/input_video.mp4",
    "-an", "-vcodec", "copy",
    "output/output_video.mp4"
], check=True)
