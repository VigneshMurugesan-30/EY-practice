import subprocess
import os

input_audio = "input/output_audio.wav"
output_dir = "output"

os.makedirs(output_dir, exist_ok=True)

subprocess.run([
    "demucs",
    "--out", output_dir,
    input_audio
], check=True)

print("✅ Demucs separation completed! Outputs are in", output_dir)
