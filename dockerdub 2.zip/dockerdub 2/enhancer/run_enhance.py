import os
from resemble_enhance.enhancer.inference import enhance, load_enhancer
from torchaudio import load, save

input_dir = "input"
output_dir = "output"
os.makedirs(output_dir, exist_ok=True)

device = "cpu"
enhancer = load_enhancer(run_dir=None, device=device)

input_file = os.path.join(input_dir, "vocals.wav")
output_file = os.path.join(output_dir, "vocals_enhanced.wav")

# Load audio
dwav, sr = load(input_file)

# Enhance
hwav, sr = enhance(dwav, sr, enhancer, device)

# Save enhanced audio
save(output_file, hwav, sr)

print("✅ Enhanced vocals.wav saved as vocals_enhanced.wav")
