import os
import torch
import torchaudio
from silero_vad import get_speech_timestamps, VADIterator

input_path = "input/vocals_enhanced.wav"

# Load audio
waveform, sample_rate = torchaudio.load(input_path)

# Load Silero VAD model
model, utils = torch.hub.load(repo_or_dir='snakers4/silero-vad', model='silero_vad', force_reload=True)
(get_speech_timestamps, _, read_audio, _, _) = utils

# Run VAD
speech_timestamps = get_speech_timestamps(waveform, model, sampling_rate=sample_rate)

# Print results
print("🗣️ Detected speech segments:")
for ts in speech_timestamps:
    start = ts['start'] / sample_rate
    end = ts['end'] / sample_rate
    print(f"Start: {start:.2f}s, End: {end:.2f}s")
